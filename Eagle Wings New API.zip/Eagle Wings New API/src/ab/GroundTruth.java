package ab;

import ab.vision.ABObject;
import ab.vision.ABType;
import java.util.Arrays;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.awt.*;
import java.awt.geom.Area;
import java.util.*;
import java.util.List;

public class GroundTruth {

    //private JSONArray gt;
    private LinkedList _birds = new LinkedList<ABObject>();
    private LinkedList _pigs = new LinkedList<ABObject>();
    private LinkedList _hills = new LinkedList<ABObject>();
    private LinkedList _allBlocks = new LinkedList<ABObject>();
    private LinkedList _tnts = new LinkedList<ABObject>();
    private Rectangle _sling = new Rectangle();
    private int _ground = 0;


    private HashMap<String,ABType> lookupTable3Color = new HashMap<>();

    private class colorPercent {
        int color;
        float percent;

        public colorPercent(int color, float percent){
            this.color = color;
            this.percent = percent;
        }

    }

    private void initialiseLookupTable(){

        // numbers are the most prominent three colors for that object

        lookupTable3Color.put("73,0,32",ABType.BlackBird);
        lookupTable3Color.put("73,32,0",ABType.BlackBird);
        lookupTable3Color.put("164,36,64",ABType.BlackBird);
        lookupTable3Color.put("64,100,0",ABType.BlackBird);
        lookupTable3Color.put("36,0,109",ABType.BlackBird);
        lookupTable3Color.put("73,0,36",ABType.BlackBird);
        lookupTable3Color.put("73,36,0",ABType.BlackBird);
        lookupTable3Color.put("119,0,36",ABType.BlueBird);
        lookupTable3Color.put("119,0,82",ABType.BlueBird);
        lookupTable3Color.put("119,0,41",ABType.BlueBird);
        lookupTable3Color.put("0,250,244",ABType.RedBird);
        lookupTable3Color.put("36,21,255",ABType.WhiteBird);
        lookupTable3Color.put("36,255,21",ABType.WhiteBird);
        lookupTable3Color.put("248,36,72",ABType.YellowBird);
        lookupTable3Color.put("248,36,212",ABType.YellowBird);
        lookupTable3Color.put("248,0,36",ABType.YellowBird);
        lookupTable3Color.put("248,36,0",ABType.YellowBird);
        lookupTable3Color.put("205,68,172",ABType.TNT);
        lookupTable3Color.put("36,68,32",ABType.Hill);
        lookupTable3Color.put("19,87,123",ABType.Ice);
        lookupTable3Color.put("123,87,19",ABType.Ice);
        lookupTable3Color.put("19,123,87",ABType.Ice);
        lookupTable3Color.put("123,19,87",ABType.Ice);
        lookupTable3Color.put("19,87,255",ABType.Ice);
        lookupTable3Color.put("19,255,87",ABType.Ice);
        lookupTable3Color.put("124,156,19",ABType.Ice);
        lookupTable3Color.put("87,123,19",ABType.Ice);
        lookupTable3Color.put("87,19,123",ABType.Ice);
        lookupTable3Color.put("19,123,255",ABType.Ice);
        lookupTable3Color.put("19,255,123",ABType.Ice);
        lookupTable3Color.put("19,123,155",ABType.Ice);
        lookupTable3Color.put("19,155,123",ABType.Ice);
        lookupTable3Color.put("19,155,136",ABType.Ice);
        lookupTable3Color.put("125,203,84",ABType.Pig);
        lookupTable3Color.put("125,36,4",ABType.Pig);
        lookupTable3Color.put("125,84,88",ABType.Pig);
        lookupTable3Color.put("125,203,4",ABType.Pig);
        lookupTable3Color.put("125,36,84",ABType.Pig);
        lookupTable3Color.put("125,84,203",ABType.Pig);
        lookupTable3Color.put("125,36,88",ABType.Pig);
        lookupTable3Color.put("125,84,80",ABType.Pig);
        lookupTable3Color.put("125,121,84",ABType.Pig);
        lookupTable3Color.put("125,84,36",ABType.Pig);
        lookupTable3Color.put("125,84,121",ABType.Pig);
        lookupTable3Color.put("125,84,0",ABType.Pig);
        lookupTable3Color.put("73,19,182",ABType.Stone);
        lookupTable3Color.put("146,73,182",ABType.Stone);
        lookupTable3Color.put("146,182,73",ABType.Stone);
        lookupTable3Color.put("182,73,146",ABType.Stone);
        lookupTable3Color.put("73,182,146",ABType.Stone);
        lookupTable3Color.put("182,146,73",ABType.Stone);
        lookupTable3Color.put("73,146,182",ABType.Stone);
        lookupTable3Color.put("136,240,172",ABType.Wood);
        lookupTable3Color.put("136,240,245",ABType.Wood);
        lookupTable3Color.put("240,136,172",ABType.Wood);
        lookupTable3Color.put("136,172,168",ABType.Wood);
        lookupTable3Color.put("136,240,208",ABType.Wood);
        lookupTable3Color.put("136,245,240",ABType.Wood);
        lookupTable3Color.put("136,172,240",ABType.Wood);
        lookupTable3Color.put("136,73,240",ABType.Wood);
        lookupTable3Color.put("136,240,19",ABType.Wood);
        lookupTable3Color.put("240,136,204",ABType.Wood);
        lookupTable3Color.put("136,245,172",ABType.Wood);
        lookupTable3Color.put("136,240,73",ABType.Wood);
    }

    public GroundTruth(JSONArray gt){

        initialiseLookupTable();



        for (int i = 0 ; i < gt.size(); i++) {
            JSONObject obj = (JSONObject)gt.get(i);
            String typeName = (String)obj.get("type");

            if (typeName.equals("Ground")){
                _ground = 480 - (int)  Math.round((double)obj.get("yindex"));
            }

            else if (typeName.equals("Slingshot")) {
                JSONArray ver = (JSONArray)obj.get("vertices");
                //System.out.println(ver);
                for (int j = 0 ; j < ver.size() ; j++){
                    JSONObject point = (JSONObject) ver.get(j);
                    double x = (double) point.get("x");
                    double y = (double) point.get("y");
                    Point p = new Point((int)x,(int)(480-y));
                    if (_sling.x==0 && _sling.y==0){
                        _sling = new Rectangle((int)x,480 - (int)y,0,0);

                    }
                    else{
                        _sling.add(p);

                    }
                }
            }

            else if (typeName.equals("Trajectory")) {
                continue;
            }

            else
                {
                // find the type of object by using color distribution
                ABType identifiedType = ABType.Unknown;
                JSONArray colormapArray = (JSONArray)obj.get("colormap");
                //System.out.println("colormapString" + colormapArray);
                //System.out.println( "True type : " + typeName);
                //System.out.println(" Color map : " + colormapString);


                List<colorPercent> cp = new LinkedList<>();

                for (int j = 0 ; j < colormapArray.size() ; j++){
                    JSONObject cl = (JSONObject) colormapArray.get(j);
                    long color = (long) cl.get("color");
                    double percent = (double) cl.get("percent");
                    cp.add(new colorPercent((int)color,(float)percent));
                }

                Collections.sort(cp,new Comparator<colorPercent>(){
                    public int compare(colorPercent s1,colorPercent s2){
                        return s1.percent < s2.percent ? 1 : s1.percent > s2.percent ? -1 : 0;
                    }});

                String typeKey = "";
                if (cp.size() == 1){
                    typeKey = Integer.toString(cp.get(0).color) + "," ;
                }
                else if (cp.size() == 2) {
                    typeKey = Integer.toString(cp.get(0).color) + "," + Integer.toString(cp.get(1).color);
                }
                else{
                    typeKey = Integer.toString(cp.get(0).color) + "," + Integer.toString(cp.get(1).color)+ "," + Integer.toString(cp.get(2).color);
                }


                //System.out.println(typeKey);
                identifiedType = lookupTable3Color.get(typeKey);
                if (identifiedType == null){
                    identifiedType = ABType.Unknown;
                }
                //System.out.println("identified type : "  + identifiedType);
                    switch (identifiedType){

                        case RedBird:
                        case BlueBird:
                        case BlackBird:
                        case WhiteBird:
                        case YellowBird:
                            ABObject bird = new ABObject();
                            JSONArray birdver = (JSONArray)obj.get("vertices");
                            //System.out.println(ver);
                            for (int j = 0 ; j < birdver.size() ; j++) {
                                JSONObject point = (JSONObject) birdver.get(j);
                                double x = (double) point.get("x");
                                double y = (double) point.get("y");
                                Point p = new Point((int) x, (int) (480 - y));

                                if (bird.x == 0 && bird.y == 0) {
                                    bird.x = (int) x;
                                    bird.y = 480 - (int) y; // as the ground truth start from the bottom left rather than top left
                                    //System.out.println(bird);
                                } else {
                                    bird.add(p);
                                    //System.out.println(bird);
                                }
                            }

                            bird.type = identifiedType;

                            //System.out.println(bird.type);

                            _birds.add(bird);

                            break;

                        case Hill:
                            ABObject platform = new ABObject();
                            JSONArray platformver = (JSONArray)obj.get("vertices");
                            //System.out.println(ver);
                            for (int j = 0 ; j < platformver.size() ; j++){
                                JSONObject point = (JSONObject) platformver.get(j);
                                double x = (double) point.get("x");
                                double y = (double) point.get("y");
                                Point p = new Point((int)x,(int)(480-y));
                                if (platform.x == 0 && platform.y == 0) {
                                    platform.x = (int) x;
                                    platform.y = 480 - (int) y;
                                    //System.out.println(bird);
                                } else {
                                    platform.add(p); // as the ground truth start from the bottom left rather than top left
                                    //System.out.println(bird);
                                }
                            }
                            platform.type = identifiedType;
                            _hills.add(platform);

                            break;

                        case Wood:
                        case Ice:
                        case Stone:
                            ABObject block = new ABObject();
                            JSONArray blockver = (JSONArray)obj.get("vertices");
                            //System.out.println(ver);
                            for (int j = 0 ; j < blockver.size() ; j++){
                                JSONObject point = (JSONObject) blockver.get(j);
                                double x = (double) point.get("x");
                                double y = (double) point.get("y");
                                Point p = new Point((int)x,(int)(480-y));
                                if (block.x == 0 && block.y == 0) {
                                    block.x = (int) x;
                                    block.y = 480 - (int) y;
                                    //System.out.println(bird);
                                } else {
                                    block.add(p);
                                    //System.out.println(bird);
                                }
                            }
                            Rectangle blockmbr = new Rectangle(block);
                            block._ar = new Area(blockmbr);
                            blockmbr.grow(block.shift,block.shift);
                            block._shiftar = new Area(blockmbr);
                            block.type = identifiedType;
                            _allBlocks.add(block);
                            break;

                        case TNT:
                            ABObject tnt = new ABObject();
                            JSONArray tntver = (JSONArray)obj.get("vertices");
                            //System.out.println(ver);
                            for (int j = 0 ; j < tntver.size() ; j++){
                                JSONObject point = (JSONObject) tntver.get(j);
                                double x = (double) point.get("x");
                                double y = (double) point.get("y");
                                Point p = new Point((int)x,(int)(480-y));
                                if (tnt.x == 0 && tnt.y == 0) {
                                    tnt.x = (int) x;
                                    tnt.y = 480 - (int) y;
                                    //System.out.println(bird);
                                } else {
                                    tnt.add(p); // as the ground truth start from the bottom left rather than top left
                                    //System.out.println(bird);
                                }
                            }

                            Rectangle tntmbr = new Rectangle(tnt);
                            tnt._ar = new Area(tntmbr);
                            tntmbr.grow(tnt.shift,tnt.shift);
                            tnt._shiftar = new Area(tntmbr);
                            tnt.type = identifiedType;
                            _tnts.add(tnt);
                            break;

                        case Pig:
                            ABObject pig = new ABObject();
                            JSONArray pigver = (JSONArray)obj.get("vertices");
                            //System.out.println(ver);
                            for (int j = 0 ; j < pigver.size() ; j++){
                                JSONObject point = (JSONObject) pigver.get(j);
                                double x = (double) point.get("x");
                                double y = (double) point.get("y");
                                Point p = new Point((int)x,(int)(480-y));

                                if (pig.x == 0 && pig.y == 0) {
                                    pig.x = (int) x;
                                    pig.y = 480 - (int) y;
                                    //System.out.println(bird);
                                } else {
                                    pig.add(p); // as the ground truth start from the bottom left rather than top left
                                    //System.out.println(bird);
                                }
                            }

                            Rectangle pigmbr = new Rectangle(pig);
                            pig._ar = new Area(pigmbr);
                            pigmbr.grow(pig.shift,pig.shift);
                            pig._shiftar = new Area(pigmbr);
                            pig.type = identifiedType;
                            _pigs.add(pig);
                            break;

                        case Unknown:
                            break;
                    }
                }




        }
    }

    public ABType getBirdTypeOnSling() {

        if (this._birds.isEmpty()) {
            return ABType.Unknown;
        }

        Collections.sort(this._birds, new Comparator<Rectangle>() {
            @Override
            public int compare(Rectangle o1, Rectangle o2) {
                return ((Integer) (o1.y)).compareTo((o2.y));
            }
        });

        Rectangle sling = _sling;

        ABObject possibleBirdOnSling = (ABObject)this._birds.get(0);



//        if (sling != null && sling.x < possibleBirdOnSling.x
//                && sling.x + sling.width > (int) possibleBirdOnSling.getCenterX()) {
//            return possibleBirdOnSling.type;
//        }

        return possibleBirdOnSling.type;
    }

    public int getGroundLevel() {

        return _ground;
    }


    public List<ABObject> findTNTs() {
        return _tnts;
    }


    public List<ABObject> findPigsRealShape() {
        return _pigs;
    }

    public List<ABObject> findBirdsRealShape() {
        return _birds;
    }

    public List<ABObject> findHills() {
        return _hills;
    }


    public Rectangle findSlingshotRealShape() {
        return _sling;
    }


    public List<ABObject> findBlocksRealShape() {
        return _allBlocks;
    }


//    public List<Point> findTrajPoints() {
//
//    }

}
