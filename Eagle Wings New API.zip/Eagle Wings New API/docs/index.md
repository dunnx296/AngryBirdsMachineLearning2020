![alt text](/docs/eagle.png)

# AI-AngryBird-Eagle-Wings
It employs a simple multi-strategy affordance based structural analysis with a manually tuned utility to decide between the strategies. It was develped on top of a fork of the agent from Team DataLab, the champion in 2014. Both the *tactic gameplay* and the *strategic gameplay* are coded in java. Major efforts were made to employ machine learning method [xgboost](https://github.com/dmlc/xgboost) and deep reinforcement learning, but they do not perform nearly as well as the simple model.

## Developer
 - Tian Jian Wang [2016-2017]


### Team Descriptions
Coming soon

## License
  [GNU Affero General Public License](https://github.com/DeMaCS-UNICAL/Angry-HEX/blob/master/LICENSE)

## Publications
 Pending
   
